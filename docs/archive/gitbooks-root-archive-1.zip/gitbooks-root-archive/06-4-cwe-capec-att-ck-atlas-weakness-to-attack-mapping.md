# 4. CWE, CAPEC, ATT&CK, ATLAS & weakness-to-attack mapping

### 4.1 CWE - Common Weakness Enumeration
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | CWE home | [cwe.mitre.org](https://cwe.mitre.org/) | Free public | Common Weakness Enumeration root. Provides standardized weakness taxonomy. | CVE-to-CWE mappings are sometimes missing, broad, or imprecise. |
| 2 | CWE downloads | [cwe.mitre.org/data/downloads.html](https://cwe.mitre.org/data/downloads.html) | Free public downloads | XML, CSV, archive bundles, & views for machine ingestion. | Use downloadable structured data for robust taxonomy ingestion. |
| 3 | CWE latest PDF | [cwe.mitre.org/data/published/cwe_latest.pdf](https://cwe.mitre.org/data/published/cwe_latest.pdf) | Free public PDF | PDF publication of latest CWE content. | Better for manual reference than automated ingestion. |
| 4 | CWE reports | [cwe.mitre.org/data/reports.html](https://cwe.mitre.org/data/reports.html) | Free public | Reports & curated views of CWE data. | Useful for understanding categories, views, & prioritization. |
| 5 | CWE chains & composites | [cwe.mitre.org/data/reports/chains_and_composites.html](https://cwe.mitre.org/data/reports/chains_and_composites.html) | Free public | Describes weakness chains & composite weaknesses. | Important for modeling multi-step root causes & compound vulnerabilities. |
| 6 | CWE schema docs | [cwe.mitre.org/documents/schema/index.html](https://cwe.mitre.org/documents/schema/index.html) | Free public | Schema documentation for CWE data. | Use for parser validation & taxonomy consistency. |
| 7 | CWE data definitions | [cwe.mitre.org/data/definitions/1000.html](https://cwe.mitre.org/data/definitions/1000.html) | Free public | CWE views & weakness hierarchy. | Useful for grouping weaknesses into higher-level categories. |
| 8 | CWE Top 25 | [cwe.mitre.org/top25](https://cwe.mitre.org/top25/) | Free public | Most dangerous software weaknesses. | Good for model priors & training labels, but not a substitute for context-specific risk. |
| 9 | CWE AI/ML category - CWE-1448 | [cwe.mitre.org/data/definitions/1448.html](https://cwe.mitre.org/data/definitions/1448.html) | Free public | AI/ML-related weakness category. | Emerging taxonomy area; expect coverage to evolve. |
| 10 | CWE AI Working Group | [cwe.mitre.org/community/working_groups.html](https://cwe.mitre.org/community/working_groups.html) | Free public | CWE/CVE AI Working Group context. | Useful for tracking evolution of AI-related weakness classifications. |
### 4.2 CAPEC - attack patterns
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | CAPEC home | [capec.mitre.org](https://capec.mitre.org/) | Free public | Catalog of attack patterns used to exploit weaknesses. | CAPEC bridges weakness taxonomy & attacker behavior patterns. |
| 2 | CAPEC downloads | [capec.mitre.org/data/downloads.html](https://capec.mitre.org/data/downloads.html) | Free public downloads | XML/CSV attack-pattern bundles. | Prefer structured downloads for ingestion. |
| 3 | CAPEC schema docs | [capec.mitre.org/documents/schema/index.html](https://capec.mitre.org/documents/schema/index.html) | Free public | Schema docs for CAPEC data. | Important for parser validation. |
| 4 | CAPEC data index | [capec.mitre.org/data/index.html](https://capec.mitre.org/data/index.html) | Free public | Browsable CAPEC entries & views. | Useful for manual mapping & explanation. |
| 5 | MITRE CTI repository - ATT&CK & CAPEC in STIX | [github.com/mitre/cti](https://github.com/mitre/cti) | Free / open-source public GitHub repo | MITRE ATT&CK & CAPEC datasets expressed in STIX 2.0. | Useful for graph-based relationships. May differ from newer ATT&CK-specific STIX repo content. |
### 4.3 MITRE ATT&CK
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | ATT&CK Enterprise Matrix | [attack.mitre.org/matrices/enterprise](https://attack.mitre.org/matrices/enterprise/) | Free public | Enterprise adversary tactics & techniques. | More relevant for adversary behavior after exploitation than raw CVE severity. |
| 2 | ATT&CK Matrices | [attack.mitre.org/matrices](https://attack.mitre.org/matrices/) | Free public | ATT&CK matrices across domains. | Useful for selecting enterprise, mobile, ICS, or other domain views. |
| 3 | ATT&CK Data & Tools | [attack.mitre.org/resources/attack-data-and-tools](https://attack.mitre.org/resources/attack-data-and-tools/) | Free public | ATT&CK Navigator, STIX/TAXII, Workbench, & tooling references. | Prefer machine-readable STIX/TAXII for ingestion. |
| 4 | ATT&CK STIX data repo | [github.com/mitre-attack/attack-stix-data](https://github.com/mitre-attack/attack-stix-data) | Free / open-source public GitHub repo | Machine-readable ATT&CK STIX data. | Best source for automated technique/tactic ingestion. |
| 5 | MITRE CTI repository | [github.com/mitre/cti](https://github.com/mitre/cti) | Free / open-source public GitHub repo | MITRE CTI STIX datasets. | Keep for historical/related STIX content. |
| 6 | ATT&CK Navigator | [mitre-attack.github.io/attack-navigator](https://mitre-attack.github.io/attack-navigator/) | Free / open-source web tool | Visual mapping of techniques to campaigns, risks, or controls. | Useful for reporting & matrix visualization, not raw vuln ingestion. |
| 7 | ATT&CK Workbench | [github.com/center-for-threat-informed-defense/attack-workbench-frontend](https://github.com/center-for-threat-informed-defense/attack-workbench-frontend) | Free / open-source public GitHub repo | Tooling for ATT&CK customization & management. | Useful for internal technique mapping workflows. |
| 8 | ATT&CK TAXII server docs | [attack.mitre.org/resources/attack-data-and-tools](https://attack.mitre.org/resources/attack-data-and-tools/) | Free public | TAXII/STIX access docs. | Same source as ATT&CK Data & Tools; retained to preserve the explicit TAXII reference. |
### 4.4 AI/ML-specific adversary frameworks
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | MITRE ATLAS | [atlas.mitre.org](https://atlas.mitre.org/) | Free public | Living knowledge base of adversary tactics & techniques against AI-enabled systems. | More directly relevant to AI systems than ATT&CK Enterprise alone. |
| 2 | MITRE ATLAS matrix | [atlas.mitre.org/matrices/ATLAS](https://atlas.mitre.org/matrices/ATLAS) | Free public | Matrix view of AI adversary tactics & techniques. | Useful for AI threat modeling & impact mapping. |
| 3 | MITRE ATLAS techniques | [atlas.mitre.org/techniques](https://atlas.mitre.org/techniques) | Free public | Technique-level ATLAS entries. | Use for structured AI attack technique mapping. |
| 4 | MITRE ATLAS case studies | [atlas.mitre.org/studies](https://atlas.mitre.org/studies) | Free public | Case studies of AI attacks & failures. | Helpful for real-world analogs & model training examples. |
| 5 | MITRE ATLAS GitHub / Adversarial ML Threat Matrix | [github.com/mitre/advmlthreatmatrix](https://github.com/mitre/advmlthreatmatrix) | Free / open-source public GitHub repo | Historical & structured project data for adversarial ML threat matrix. | May not be the most current ATLAS view; keep for lineage. |
| 6 | MITRE SAFE-AI report | [atlas.mitre.org/pdf-files/SAFEAI_Full_Report.pdf](https://atlas.mitre.org/pdf-files/SAFEAI_Full_Report.pdf) | Free public PDF | AI system risk mapping across model, data, platform, & environment layers. | Useful for AI-specific control mapping & architecture risk analysis. |
| 7 | OWASP Top 10 for LLM Applications | [owasp.org/www-project-top-10-for-large-language-model-applications](https://owasp.org/www-project-top-10-for-large-language-model-applications/) | Free / open-source community project | Practical LLM application vulnerability taxonomy. | Useful for AI appsec detection categories beyond CVE. |
| 8 | OWASP Top 10 for Machine Learning Security | [owasp.org/www-project-machine-learning-security-top-10](https://owasp.org/www-project-machine-learning-security-top-10/) | Free / open-source community project | ML-specific application/security risk taxonomy. | Complements ATLAS with appsec-oriented framing. |
| 9 | OWASP AI Exchange | [owaspai.org](https://owaspai.org/) | Free public community resource | AI security risks, controls, & threat modeling references. | Useful for governance & risk mapping. |
| 10 | NIST AI Risk Management Framework | [www.nist.gov/itl/ai-risk-management-framework](https://www.nist.gov/itl/ai-risk-management-framework) | Free public | AI risk management framework. | Useful for risk controls, governance, & impact framing. |
| 11 | NIST AI RMF 1.0 PDF | [nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf](https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf) | Free public PDF | AI RMF 1.0 document. | PDF reference; not a vulnerability feed. |
| 12 | NIST AI 600-1 - Generative AI Profile | [www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence](https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence) | Free public | GenAI risk profile companion to AI RMF. | Useful for LLM/generative AI-specific risk categories. |
| 13 | NIST adversarial machine learning taxonomy | [www.nist.gov/publications/adversarial-machine-learning-taxonomy-and-terminology-attacks-and-mitigations](https://www.nist.gov/publications/adversarial-machine-learning-taxonomy-and-terminology-attacks-and-mitigations) | Free public | Taxonomy & terminology for adversarial ML attacks & mitigations. | Good for consistent AI vulnerability vocabulary. |
| 14 | MLCommons AI Safety | [mlcommons.org/working-groups/ai-safety](https://mlcommons.org/working-groups/ai-safety/) | Free public community resource | AI safety benchmarks & working group context. | Useful for AI system risk evaluation, not direct CVE matching. |
> #### [*Back to **`Index`***](#index)
---
