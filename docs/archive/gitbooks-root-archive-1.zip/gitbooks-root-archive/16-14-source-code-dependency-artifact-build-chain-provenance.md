# 14. Source-code, dependency, artifact & build-chain provenance

### 14.1 Source & artifact provenance
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | SLSA | [slsa.dev](https://slsa.dev/) | Free / open standard | Supply-chain Levels for Software Artifacts. | Useful for evaluating build integrity & provenance risk. |
| 2 | Sigstore | [www.sigstore.dev](https://www.sigstore.dev/) | Free / open-source public infrastructure | Signing & verification for software artifacts. | Helps verify artifact integrity & publisher identity. |
| 3 | Cosign | [github.com/sigstore/cosign](https://github.com/sigstore/cosign) | Free / open-source public GitHub repo | Container/artifact signing tool. | Useful for verifying container image provenance. |
| 4 | Rekor | [docs.sigstore.dev/logging/overview](https://docs.sigstore.dev/logging/overview/) | Free public docs / public transparency log | Transparency log for signed artifacts. | Useful for auditability & tamper detection. |
| 5 | in-toto | [in-toto.io](https://in-toto.io/) | Free / open-source | Supply-chain integrity framework. | Useful for verifying build steps & provenance attestations. |
| 6 | The Update Framework - TUF | [theupdateframework.io](https://theupdateframework.io/) | Free / open-source | Secure software update framework. | Useful for update-channel compromise resistance. |
| 7 | SLSA GitHub generators | [github.com/slsa-framework/slsa-github-generator](https://github.com/slsa-framework/slsa-github-generator) | Free / open-source public GitHub repo | GitHub-based SLSA provenance generators. | Useful for CI/CD provenance generation. |
### 14.2 Dependency inventory & graphing
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | deps.dev | [deps.dev](https://deps.dev/) | Free public | Dependency metadata, transitive dependency graphing, & security signals. | Useful for OSS dependency context. |
| 2 | GUAC | [guac.sh](https://guac.sh/) | Free public / open-source project | Graph for software supply-chain metadata. | Useful for correlating SBOMs, vulnerabilities, provenance, & attestations. |
| 3 | GUAC GitHub | [github.com/guacsec/guac](https://github.com/guacsec/guac) | Free / open-source public GitHub repo | GUAC implementation repository. | Reference architecture for software supply-chain knowledge graphs. |
| 4 | OpenSSF Scorecard | [github.com/ossf/scorecard](https://github.com/ossf/scorecard) | Free / open-source public GitHub repo | Open-source project security practice scoring. | Useful as a dependency risk signal. |
| 5 | OpenSSF Scorecard API | [api.securityscorecards.dev](https://api.securityscorecards.dev/) | Free public API subject to service limits | API for Scorecard results. | Scores are temporal; store retrieval time. |
| 6 | Maven Central | [central.sonatype.com](https://central.sonatype.com/) | Free public | Maven package metadata. | Useful for Java dependency resolution. |
| 7 | npm registry | [registry.npmjs.org](https://registry.npmjs.org/) | Free public registry API | npm package registry API endpoint. | Useful for package metadata & version resolution. |
| 8 | PyPI JSON API | [docs.pypi.org/api/json](https://docs.pypi.org/api/json/) | Free public API docs / public API | PyPI JSON API documentation. | Useful for Python package metadata. |
| 9 | crates.io API | [crates.io/data-access](https://crates.io/data-access) | Free public API subject to policy/rate limits | crates.io data access documentation. | Useful for Rust package metadata. |
| 10 | Go module proxy | [proxy.golang.org](https://proxy.golang.org/) | Free public | Go module proxy. | Useful for Go module version metadata. |
> #### [*Back to **`Index`***](#index)
---
