# 13. Compliance, baseline configuration & exposure severity standards

These are not vulnerability feeds, but they help assess impact, control failure, configuration exposure, & exploitability in a given environment.
### 13.1 Security configuration & benchmarks
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | CIS Benchmarks | [www.cisecurity.org/cis-benchmarks](https://www.cisecurity.org/cis-benchmarks) | Free with registration for many PDFs; commercial CIS tools/membership available | Secure configuration benchmarks. | Useful for environmental risk scoring & hardening validation. |
| 2 | CIS Controls | [www.cisecurity.org/controls](https://www.cisecurity.org/controls) | Free public | Security control framework. | Useful for vulnerability management program alignment. |
| 3 | NIST National Checklist Program | [ncp.nist.gov](https://ncp.nist.gov/) | Free public | Repository of security configuration checklists. | Useful for baseline configuration assessment. |
| 4 | DISA STIGs | [public.cyber.mil/stigs](https://public.cyber.mil/stigs/) | Free public | Security Technical Implementation Guides. | Important for government/defense compliance. |
| 5 | OpenSCAP | [www.open-scap.org](https://www.open-scap.org/) | Free / open-source | SCAP tooling for compliance scanning. | Useful for host-level configuration scanning. |
| 6 | SCAP Security Guide | [github.com/ComplianceAsCode/content](https://github.com/ComplianceAsCode/content) | Free / open-source public GitHub repo | ComplianceAsCode content for SCAP profiles. | Useful for policy-as-code & baseline validation. |
### 13.2 Cloud configuration posture
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | Prowler - AWS/Azure/GCP/Kubernetes | [github.com/prowler-cloud/prowler](https://github.com/prowler-cloud/prowler) | Free / open-source core; commercial product available | Cloud & Kubernetes security posture scanning. | Useful for environmental exposure & misconfiguration risk. |
| 2 | CloudSplaining | [github.com/salesforce/cloudsplaining](https://github.com/salesforce/cloudsplaining) | Free / open-source public GitHub repo | AWS IAM policy risk analysis. | Useful for blast-radius & privilege exposure context. |
| 3 | ScoutSuite | [github.com/nccgroup/ScoutSuite](https://github.com/nccgroup/ScoutSuite) | Free / open-source public GitHub repo | Multi-cloud security auditing. | Useful for cloud misconfiguration assessment. |
| 4 | Steampipe mods | [hub.steampipe.io/mods](https://hub.steampipe.io/mods) | Free/open-source mods; commercial Turbot/Steampipe offerings separate | SQL-based cloud/security posture checks. | Useful for custom exposure queries. |
| 5 | Cloud Custodian | [cloudcustodian.io](https://cloudcustodian.io/) | Free / open-source | Cloud governance & policy automation. | Useful for remediation automation. |
| 6 | Kubernetes CIS benchmark | [www.cisecurity.org/benchmark/kubernetes](https://www.cisecurity.org/benchmark/kubernetes) | Free with registration for benchmark PDFs; commercial CIS tools/membership available | Kubernetes configuration benchmark. | Useful for cluster hardening & exposure scoring. |
| 7 | kube-bench | [github.com/aquasecurity/kube-bench](https://github.com/aquasecurity/kube-bench) | Free / open-source public GitHub repo | Kubernetes CIS benchmark scanner. | Useful for automated cluster benchmark checks. |
| 8 | kube-hunter | [github.com/aquasecurity/kube-hunter](https://github.com/aquasecurity/kube-hunter) | Free / open-source public GitHub repo | Kubernetes penetration testing tool. | Use only in authorized environments. |
> #### [*Back to **`Index`***](#index)
---
