# 8. Malicious package, supply-chain compromise & package reputation sources

### 8.1 Malicious package databases
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | OpenSSF Malicious Packages repository | [github.com/ossf/malicious-packages](https://github.com/ossf/malicious-packages) | Free / open-source public GitHub repo | Public malicious package reports consumable via OSV format. | Covers malicious packages, which may not be CVEs. |
| 2 | OpenSSF Malicious Packages announcement | [openssf.org/blog/2023/10/12/introducing-openssfs-malicious-packages-repository](https://openssf.org/blog/2023/10/12/introducing-openssfs-malicious-packages-repository/) | Free public | Explains the public DB for malicious package reports. | Context source, not the primary data feed. |
| 3 | OpenSSF Package Analysis | [openssf.org/package-analysis](https://openssf.org/package-analysis/) | Free public project info | Detects malicious package behavior & informs package consumers. | Behavioral analysis may surface packages before CVE/advisory assignment. |
| 4 | OpenSSF Package Analysis GitHub | [github.com/ossf/package-analysis](https://github.com/ossf/package-analysis) | Free / open-source public GitHub repo | Open-source package analysis system. | Useful for detection logic & behavioral signal review. |
| 5 | OpenSSF Package Feeds | [github.com/ossf/package-feeds](https://github.com/ossf/package-feeds) | Free / open-source public GitHub repo | Package ecosystem feed monitoring. | Useful for observing new packages in ecosystems. |
| 6 | GitHub malware advisories | [github.com/advisories?query=type%3Amalware](https://github.com/advisories?query=type%3Amalware) | Free public | GitHub malware advisories across ecosystems. | Treat as supply-chain compromise data, not conventional vuln data. |
| 7 | npm malware advisories via GitHub | [github.com/advisories?query=ecosystem%3Anpm+type%3Amalware](https://github.com/advisories?query=ecosystem%3Anpm+type%3Amalware) | Free public | npm-specific malware advisories. | npm has high malicious package volume; prioritize transitive dependency visibility. |
| 8 | PyPI malware advisories via GitHub | [github.com/advisories?query=ecosystem%3Apip+type%3Amalware](https://github.com/advisories?query=ecosystem%3Apip+type%3Amalware) | Free public | PyPI-specific malware advisories. | Use with lockfiles & package provenance checks. |
| 9 | Socket.dev blog | [socket.dev/blog](https://socket.dev/blog) | Free public blog; product/API features may be commercial | Supply-chain attack research & malicious package analysis. | Research feed; verify indicators before automated blocking. |
| 10 | Snyk vulnerability database | [security.snyk.io](https://security.snyk.io/) | Free public search; commercial plans/API features | Snyk vulnerability & package risk database. | Commercial/community source; validate licensing & provenance. |
| 11 | Sonatype OSS Index | [ossindex.sonatype.org](https://ossindex.sonatype.org/) | Free tier / API terms; commercial Sonatype products separate | OSS vulnerability intelligence. | Useful for package risk enrichment. |
| 12 | Sonatype vulnerability database | [sonatype.com/resources/vulnerability-database](https://sonatype.com/resources/vulnerability-database) | Free public search; commercial ecosystem | Sonatype vulnerability database. | Good secondary enrichment source. |
| 13 | Phylum research | [blog.phylum.io](https://blog.phylum.io/) | Free public blog; commercial products separate | Software supply-chain attack research. | Research source; useful for malicious package trends. |
| 14 | ReversingLabs threat research | [www.reversinglabs.com/blog](https://www.reversinglabs.com/blog) | Free public blog; commercial products separate | Threat research focused on malware & supply-chain compromise. | Use for context, not as canonical package advisory data. |
| 15 | Checkmarx supply-chain research | [checkmarx.com/blog](https://checkmarx.com/blog/) | Free public blog; commercial products separate | Supply-chain & application security research. | Useful for emerging package attack patterns. |
### 8.2 Package reputation / dependency health
| Sl. # | Title | Link(s) | Access / Cost | Relevance | Notes & POIs |
|---:|---|---|---|---|---|
| 1 | OpenSSF Scorecard | [github.com/ossf/scorecard](https://github.com/ossf/scorecard) | Free / open-source public GitHub repo | Scores open-source project security practices. | Useful as dependency risk signal, not vulnerability proof. |
| 2 | OpenSSF Scorecard API | [api.securityscorecards.dev](https://api.securityscorecards.dev/) | Free public API subject to service limits | API for Scorecard results. | Use with timestamped results because scores change over time. |
| 3 | OpenSSF Best Practices Badge | [www.bestpractices.dev](https://www.bestpractices.dev/) | Free public | Project best-practices badge program. | Useful project maturity signal, not vulnerability evidence. |
| 4 | deps.dev | [deps.dev](https://deps.dev/) | Free public | Dependency metadata, transitive dependencies, security signals. | Useful for dependency graphing & package metadata. |
| 5 | OpenSSF GUAC | [guac.sh](https://guac.sh/) | Free public / open-source project | Graph for software supply-chain metadata. | Useful for correlating SBOMs, attestations, vulnerabilities, & provenance. |
| 6 | GUAC GitHub | [github.com/guacsec/guac](https://github.com/guacsec/guac) | Free / open-source public GitHub repo | GUAC implementation repository. | Reference architecture for supply-chain knowledge graphs. |
| 7 | Sigstore | [www.sigstore.dev](https://www.sigstore.dev/) | Free / open-source public infrastructure | Signing & verification for software artifacts. | Helps assess provenance & tamper resistance. |
| 8 | Rekor transparency log | [docs.sigstore.dev/logging/overview](https://docs.sigstore.dev/logging/overview/) | Free public docs / public transparency log | Transparency log for signed artifacts. | Useful for provenance verification & audit trails. |
| 9 | SLSA framework | [slsa.dev](https://slsa.dev/) | Free / open standard | Supply-chain Levels for Software Artifacts. | Helps assess build integrity & supply-chain hardening. |
> #### [*Back to **`Index`***](#index)
---
