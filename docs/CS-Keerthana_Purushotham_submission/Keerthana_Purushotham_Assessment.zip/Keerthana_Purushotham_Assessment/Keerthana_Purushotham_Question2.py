#!/usr/bin/env python3
"""
Keerthana_Purushotham_Question2.py

Purpose:
  Identify log4j-core instances in a chosen OS scan root. Report the log4j-core
  file, the log4j-core version, the associated application file, and the
  associated application version when discoverable.

Assumptions:
  - Intended OS for validation is Ubuntu 24.04 or another Linux/macOS host, but
    the script uses only standard-library Python and can scan any local directory.
  - Java archives are ZIP-compatible containers: .jar, .war, .ear, and .zip.
  - Maven pom.properties for org.apache.logging.log4j:log4j-core is the strongest
    version signal. Manifest and filename parsing are fallbacks.
  - The default scan root should be bounded for assessment. Do not scan / on a
    production host unless explicitly authorized.

Uncovered edge cases:
  - A shaded jar can remove Maven metadata entirely. The script then falls back to
    filenames and manifest strings, which may be less precise.
  - Deeply nested archives beyond --max-nested-depth are skipped by design.
  - Very large archives or nested entries above configured limits are skipped to
    avoid high load.
  - A parent application version is only reported when it appears in the parent
    archive manifest, Maven metadata, or filename.

Safety and load-control behavior:
  - No network calls, no archive execution, and no class loading.
  - os.walk prunes virtual/system directories and honors --max-archives,
    --max-archive-size, --max-nested-size, and --max-nested-depth.
  - Malformed archives are recorded as warnings and do not stop the scan.

Output:
  Writes Keerthana_Purushotham_Question2.txt by default, including the operating
  system where the script ran.
"""

from __future__ import annotations

import argparse
import datetime as dt
import io
import os
import platform
import re
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

OUTPUT_DEFAULT = "Keerthana_Purushotham_Question2.txt"
ARCHIVE_SUFFIXES = {".jar", ".war", ".ear", ".zip"}
LOG4J_POM_PATH = "META-INF/maven/org.apache.logging.log4j/log4j-core/pom.properties"
SKIP_DIRS = {"/proc", "/sys", "/dev", "/run", "/tmp", "/var/tmp"}


@dataclass
class Finding:
    associated_application_file: str
    associated_application_version: str
    log4j_file: str
    log4j_version: str
    detection_method: str
    nesting_depth: int
    notes: list[str] = field(default_factory=list)


def now_utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def os_summary() -> str:
    os_release = Path("/etc/os-release")
    if os_release.exists():
        values: dict[str, str] = {}
        try:
            for line in os_release.read_text(encoding="utf-8", errors="replace").splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    values[key] = value.strip().strip('"')
            if values.get("PRETTY_NAME"):
                return f"{values['PRETTY_NAME']} ({platform.platform()})"
        except OSError:
            pass
    return platform.platform()


def parse_properties(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        result[key.strip()] = value.strip()
    return result


def read_archive_text(archive: zipfile.ZipFile, name: str, limit: int = 262144) -> str:
    try:
        info = archive.getinfo(name)
        if info.file_size > limit:
            return ""
        with archive.open(info) as handle:
            return handle.read(limit).decode("utf-8", errors="replace")
    except Exception:
        return ""


def manifest_values(archive: zipfile.ZipFile) -> dict[str, str]:
    text = read_archive_text(archive, "META-INF/MANIFEST.MF")
    values: dict[str, str] = {}
    current_key = ""
    for line in text.splitlines():
        if line.startswith(" ") and current_key:
            values[current_key] += line[1:]
        elif ":" in line:
            key, value = line.split(":", 1)
            current_key = key.strip()
            values[current_key] = value.strip()
    return values


def version_from_filename(name: str) -> str:
    base = Path(name).name
    match = re.search(r"(?:log4j-core|[-_])[-_]?([0-9]+(?:\.[0-9A-Za-z_-]+)+)", base, re.IGNORECASE)
    if match:
        return match.group(1).rstrip(".jarwarzip")
    generic = re.search(r"[-_]([0-9]+(?:\.[0-9A-Za-z_-]+)+)(?:\.(?:jar|war|ear|zip))$", base, re.IGNORECASE)
    return generic.group(1) if generic else ""


def application_version_from_archive(archive: zipfile.ZipFile, archive_name: str) -> str:
    manifest = manifest_values(archive)
    for key in ("Implementation-Version", "Bundle-Version", "Specification-Version"):
        if manifest.get(key):
            return manifest[key]
    for name in archive.namelist():
        if name.endswith("pom.properties") and "/log4j-core/" not in name:
            values = parse_properties(read_archive_text(archive, name))
            if values.get("version"):
                return values["version"]
    return version_from_filename(archive_name)


def log4j_metadata(archive: zipfile.ZipFile, archive_name: str) -> tuple[str, str]:
    names = set(archive.namelist())
    if LOG4J_POM_PATH in names:
        values = parse_properties(read_archive_text(archive, LOG4J_POM_PATH))
        if values.get("artifactId") == "log4j-core" and values.get("version"):
            return values["version"], "maven pom.properties"
        if values.get("version"):
            return values["version"], "maven pom.properties version fallback"
    manifest = manifest_values(archive)
    manifest_blob = " ".join(f"{key}={value}" for key, value in manifest.items()).lower()
    if "log4j-core" in Path(archive_name).name.lower() or "apache log4j core" in manifest_blob or "org.apache.logging.log4j.core" in manifest_blob:
        for key in ("Implementation-Version", "Bundle-Version", "Specification-Version"):
            if manifest.get(key):
                return manifest[key], f"manifest {key}"
        guessed = version_from_filename(archive_name)
        if guessed:
            return guessed, "filename fallback"
    return "", ""


def iter_archives(root: Path, max_archives: int, max_archive_size: int) -> tuple[list[Path], list[str]]:
    archives: list[Path] = []
    warnings: list[str] = []
    root = root.resolve()
    for current_root, subdirs, filenames in os.walk(root):
        current_path = Path(current_root)
        subdirs[:] = [d for d in subdirs if str((current_path / d).resolve()) not in SKIP_DIRS]
        for filename in filenames:
            path = current_path / filename
            if path.suffix.lower() not in ARCHIVE_SUFFIXES:
                continue
            try:
                size = path.stat().st_size
            except OSError as error:
                warnings.append(f"cannot stat {path}: {error}")
                continue
            if size > max_archive_size:
                warnings.append(f"skipped large archive {path} ({size} bytes)")
                continue
            archives.append(path)
            if len(archives) >= max_archives:
                warnings.append(f"max archive limit reached: {max_archives}")
                return archives, warnings
    return archives, warnings


def scan_archive_bytes(
    archive_bytes: bytes,
    archive_display_name: str,
    associated_application_file: str,
    associated_application_version: str,
    depth: int,
    max_nested_depth: int,
    max_nested_size: int,
) -> tuple[list[Finding], list[str]]:
    findings: list[Finding] = []
    warnings: list[str] = []
    try:
        with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
            log4j_version, method = log4j_metadata(archive, archive_display_name)
            if log4j_version:
                findings.append(Finding(
                    associated_application_file=associated_application_file,
                    associated_application_version=associated_application_version or "unknown",
                    log4j_file=archive_display_name,
                    log4j_version=log4j_version,
                    detection_method=method,
                    nesting_depth=depth,
                ))
            if depth >= max_nested_depth:
                return findings, warnings
            for info in archive.infolist():
                if Path(info.filename).suffix.lower() not in ARCHIVE_SUFFIXES:
                    continue
                if info.file_size > max_nested_size:
                    warnings.append(f"skipped large nested archive {archive_display_name}!{info.filename}")
                    continue
                try:
                    nested_bytes = archive.read(info)
                except Exception as error:
                    warnings.append(f"could not read nested archive {archive_display_name}!{info.filename}: {error}")
                    continue
                nested_findings, nested_warnings = scan_archive_bytes(
                    nested_bytes,
                    f"{archive_display_name}!{info.filename}",
                    associated_application_file,
                    associated_application_version,
                    depth + 1,
                    max_nested_depth,
                    max_nested_size,
                )
                findings.extend(nested_findings)
                warnings.extend(nested_warnings)
    except zipfile.BadZipFile:
        warnings.append(f"malformed or non-ZIP archive: {archive_display_name}")
    except Exception as error:
        warnings.append(f"error scanning {archive_display_name}: {error}")
    return findings, warnings


def scan_top_archive(path: Path, max_nested_depth: int, max_nested_size: int) -> tuple[list[Finding], list[str]]:
    warnings: list[str] = []
    try:
        with zipfile.ZipFile(path) as archive:
            associated_version = application_version_from_archive(archive, str(path))
        data = path.read_bytes()
        return scan_archive_bytes(data, str(path), str(path), associated_version, 0, max_nested_depth, max_nested_size)
    except zipfile.BadZipFile:
        return [], [f"malformed or non-ZIP archive: {path}"]
    except OSError as error:
        return [], [f"cannot read archive {path}: {error}"]


def write_report(output: Path, root: Path, findings: list[Finding], warnings: list[str]) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    unique_keys = set()
    deduped: list[Finding] = []
    for finding in findings:
        key = (finding.associated_application_file, finding.log4j_file, finding.log4j_version)
        if key not in unique_keys:
            unique_keys.add(key)
            deduped.append(finding)
    with output.open("w", encoding="utf-8", newline="\n") as report:
        report.write("Keerthana_Purushotham_Question2 - log4j-core Discovery\n")
        report.write("=" * 78 + "\n\n")
        report.write(f"Generated UTC: {now_utc()}\n")
        report.write(f"Operating system the script was run on: {os_summary()}\n")
        report.write(f"Python runtime: {sys.version.replace(chr(10), ' ')}\n")
        report.write(f"Scan root: {root}\n")
        report.write(f"Findings: {len(deduped)}\n\n")
        report.write("Findings\n")
        report.write("-" * 78 + "\n")
        if not deduped:
            report.write("No log4j-core instances identified.\n")
        for number, finding in enumerate(sorted(deduped, key=lambda item: item.log4j_file), 1):
            report.write(f"[{number}] Associated application file: {finding.associated_application_file}\n")
            report.write(f"    Associated application version: {finding.associated_application_version}\n")
            report.write(f"    log4j-core file: {finding.log4j_file}\n")
            report.write(f"    log4j-core version: {finding.log4j_version}\n")
            report.write(f"    Detection method: {finding.detection_method}\n")
            report.write(f"    Nesting depth: {finding.nesting_depth}\n\n")
        report.write("Warnings / skipped items\n")
        report.write("-" * 78 + "\n")
        if not warnings:
            report.write("No warnings.\n")
        for warning in warnings:
            report.write(f"- {warning}\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Discover log4j-core instances in bounded Java archives.")
    parser.add_argument("--root", default=".", help="Bounded local scan root. Default: current directory.")
    parser.add_argument("--output", default=OUTPUT_DEFAULT)
    parser.add_argument("--max-archives", type=int, default=20000)
    parser.add_argument("--max-archive-size", type=int, default=250 * 1024 * 1024)
    parser.add_argument("--max-nested-size", type=int, default=100 * 1024 * 1024)
    parser.add_argument("--max-nested-depth", type=int, default=3)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.root)
    warnings: list[str] = []
    if not root.exists():
        warnings.append(f"scan root does not exist: {root}")
        write_report(Path(args.output), root, [], warnings)
        return 2
    archives, archive_warnings = iter_archives(root, max(1, args.max_archives), max(1, args.max_archive_size))
    warnings.extend(archive_warnings)
    findings: list[Finding] = []
    for archive_path in archives:
        new_findings, new_warnings = scan_top_archive(archive_path, max(0, args.max_nested_depth), max(1, args.max_nested_size))
        findings.extend(new_findings)
        warnings.extend(new_warnings)
    write_report(Path(args.output), root, findings, warnings)
    print(f"Wrote report: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
