#!/usr/bin/env python3
"""
Keerthana_Purushotham_Question4.py

Purpose:
  Fetch all advertised public SSH host keys from one explicitly authorized remote
  machine using ssh-keyscan, then report raw keys and SHA256 fingerprints.

Assumptions:
  - The caller is authorized to query the specified host and port.
  - OpenSSH ssh-keyscan is available on the machine running the script.
  - Default key types are rsa, ecdsa, and ed25519. Other types can be requested
    through --types.
  - The script records host-key material; it does not prove host authenticity by
    itself. Compare fingerprints with a trusted channel before trusting a host.

Uncovered edge cases:
  - Some servers intentionally disable one or more host key algorithms.
  - Middleboxes, port knocking, DNS filtering, allowlists, or rate limits may
    prevent collection even when SSH is otherwise available.
  - A server may return duplicate lines for multiple address forms.

Safety and load-control behavior:
  - Exactly one host and one port are queried per run.
  - No username, password, private key, agent, shell, or login attempt is used.
  - The script performs no subnet scan, no port range scan, and no retry loop.
  - ssh-keyscan is run with a timeout.

Graceful error handling:
  - Missing ssh-keyscan, DNS failure, timeout, connection refused, and no keys
    returned are written as report warnings rather than unhandled exceptions.

Output:
  Writes Keerthana_Purushotham_Question4.txt by default, including the operating
  system where the script ran.
"""

from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import platform
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

OUTPUT_DEFAULT = "Keerthana_Purushotham_Question4.txt"
DEFAULT_TYPES = "rsa,ecdsa,ed25519"


@dataclass
class HostKey:
    host_field: str
    key_type: str
    public_key_blob: str
    raw_line: str
    sha256_fingerprint: str


def now_utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def os_summary() -> str:
    os_release = Path("/etc/os-release")
    if os_release.exists():
        values: dict[str, str] = {}
        try:
            for line in os_release.read_text(encoding="utf-8", errors="replace").splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    values[key] = value.strip().strip('"')
            if values.get("PRETTY_NAME"):
                return f"{values['PRETTY_NAME']} ({platform.platform()})"
        except OSError:
            pass
    return platform.platform()


def run(command: list[str], timeout: int) -> tuple[int, str, str]:
    try:
        completed = subprocess.run(
            command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=timeout, check=False,
        )
        return completed.returncode, completed.stdout, completed.stderr
    except FileNotFoundError:
        return 127, "", f"command not found: {command[0]}"
    except subprocess.TimeoutExpired as error:
        return 124, error.stdout or "", f"command timed out after {timeout}s"
    except Exception as error:
        return 1, "", f"command failed: {error}"


def sha256_fingerprint(public_key_blob: str) -> str:
    try:
        decoded = base64.b64decode(public_key_blob.encode("ascii"), validate=True)
        digest = hashlib.sha256(decoded).digest()
        return "SHA256:" + base64.b64encode(digest).decode("ascii").rstrip("=")
    except Exception as error:
        return f"fingerprint-error:{error}"


def parse_keyscan(stdout: str) -> list[HostKey]:
    keys: list[HostKey] = []
    for raw_line in stdout.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 3:
            continue
        host_field, key_type, public_key_blob = parts[:3]
        if not re.match(r"^(ssh-rsa|rsa-sha2-256|rsa-sha2-512|ecdsa-sha2-|ssh-ed25519|ssh-dss)", key_type):
            continue
        keys.append(HostKey(host_field, key_type, public_key_blob, line, sha256_fingerprint(public_key_blob)))
    return keys


def collect(host: str, port: int, key_types: str, timeout: int) -> tuple[list[HostKey], list[str], int]:
    warnings: list[str] = []
    if shutil.which("ssh-keyscan") is None:
        return [], ["ssh-keyscan not found; install OpenSSH client tools."], 127
    command = ["ssh-keyscan", "-T", str(max(1, timeout)), "-p", str(port), "-t", key_types, host]
    code, stdout, stderr = run(command, max(2, timeout + 3))
    if stderr.strip():
        warnings.append(stderr.strip())
    keys = parse_keyscan(stdout)
    if not keys:
        warnings.append("No host keys returned for the requested host, port, and key types.")
    return keys, warnings, code


def write_report(output: Path, host: str, port: int, key_types: str, timeout: int, exit_code: int, keys: list[HostKey], warnings: list[str]) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    seen = set()
    unique_keys: list[HostKey] = []
    for key in keys:
        unique = (key.host_field, key.key_type, key.public_key_blob)
        if unique not in seen:
            seen.add(unique)
            unique_keys.append(key)
    with output.open("w", encoding="utf-8", newline="\n") as report:
        report.write("Keerthana_Purushotham_Question4 - SSH Host Key Collection\n")
        report.write("=" * 78 + "\n\n")
        report.write(f"Generated UTC: {now_utc()}\n")
        report.write(f"Operating system the script was run on: {os_summary()}\n")
        report.write(f"Python runtime: {sys.version.replace(chr(10), ' ')}\n")
        report.write(f"Target host: {host}\n")
        report.write(f"Target port: {port}\n")
        report.write(f"Requested key types: {key_types}\n")
        report.write(f"Timeout seconds: {timeout}\n")
        report.write(f"ssh-keyscan exit code: {exit_code}\n")
        report.write("Authentication attempted: no\n")
        report.write("Network scope: one explicit host and one explicit port\n\n")
        report.write("Host keys\n")
        report.write("-" * 78 + "\n")
        if not unique_keys:
            report.write("No host keys collected.\n")
        for number, key in enumerate(unique_keys, 1):
            report.write(f"[{number}] Host field: {key.host_field}\n")
            report.write(f"    Key type: {key.key_type}\n")
            report.write(f"    SHA256 fingerprint: {key.sha256_fingerprint}\n")
            report.write(f"    Raw host key: {key.raw_line}\n\n")
        report.write("Warnings / notes\n")
        report.write("-" * 78 + "\n")
        if not warnings:
            report.write("No warnings.\n")
        for warning in warnings:
            report.write(f"- {warning}\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fetch SSH public host keys without logging in.")
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=22)
    parser.add_argument("--types", default=DEFAULT_TYPES)
    parser.add_argument("--timeout", type=int, default=5)
    parser.add_argument("--output", default=OUTPUT_DEFAULT)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not (1 <= args.port <= 65535):
        raise SystemExit("--port must be between 1 and 65535")
    key_types = ",".join(part.strip() for part in args.types.split(",") if part.strip())
    if not key_types:
        raise SystemExit("--types must contain at least one key type")
    keys, warnings, exit_code = collect(args.host, args.port, key_types, max(1, args.timeout))
    write_report(Path(args.output), args.host, args.port, key_types, max(1, args.timeout), exit_code, keys, warnings)
    print(f"Wrote report: {args.output}")
    return 0 if keys else 2


if __name__ == "__main__":
    raise SystemExit(main())
