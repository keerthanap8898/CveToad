```
@keerthanap8898 ➜ /workspaces/CrowdStrike-VulnDetection-KP/Answers-FULL-length (main) $ tree
.
├── A_CommonDetectionIssues_Q1-2
│   ├── Keerthana_Purushotham_1.py
│   ├── Keerthana_Purushotham_1.txt
│   └── Keerthana_Purushotham_2.txt
├── B_VulnerabilityAnalysis_Q3-7
│   ├── KeerthanaP_3_Rx-Notes.txt
│   ├── KeerthanaP_4_rx-Notes.txt
│   ├── Keerthana_Purushotham_3.txt
│   └── Keerthana_Purushotham_4.txt
├── C_OpenEndedQuestions_Q5-6-7
│   ├── Keerthana_Purushotham_5.txt
│   ├── Keerthana_Purushotham_6.txt
│   └── Keerthana_Purushotham_7.txt
├── D_VulnRx_codeDesign_Q1-4
│   ├── KeerthanaP_VMsetup_Runbook.txt
│   ├── Keerthana_Purushotham_Question1.py
│   ├── Keerthana_Purushotham_Question1.txt
│   ├── Keerthana_Purushotham_Question1_requirements.txt
│   ├── Keerthana_Purushotham_Question2.py
│   ├── Keerthana_Purushotham_Question2.txt
│   ├── Keerthana_Purushotham_Question2_requirements.txt
│   ├── Keerthana_Purushotham_Question3.py
│   ├── Keerthana_Purushotham_Question3.txt
│   ├── Keerthana_Purushotham_Question3_requirements.txt
│   ├── Keerthana_Purushotham_Question4.py
│   ├── Keerthana_Purushotham_Question4.txt
│   └── Keerthana_Purushotham_Question4_requirements.txt
├── Logs_&_Resources
│   ├── 0_cmdLineLog.txt
│   ├── 1_cmdLineLog.txt
│   ├── 2_cmdLineLog.txt
│   ├── 3_cmdLineLog.txt
│   ├── 4_cmdLineLog.txt
│   ├── QUESTIONS-Exam-format.md
│   ├── fqUsed_DevTools_&_personal_github_opensrc_tools.txt
│   └── work
│       ├── fixtures
│       │   └── q2
│       │       ├── direct
│       │       │   └── META-INF
│       │       │       ├── MANIFEST.MF
│       │       │       └── maven
│       │       │           └── org.apache.logging.log4j
│       │       │               └── log4j-core
│       │       │                   └── pom.properties
│       │       ├── false
│       │       │   └── log4j-core-9.9.9.jar.txt
│       │       ├── log4j-core-2.17.1.jar
│       │       ├── nested-app
│       │       │   ├── BOOT-INF
│       │       │   │   └── lib
│       │       │   │       └── log4j-core-2.17.1.jar
│       │       │   └── META-INF
│       │       │       └── MANIFEST.MF
│       │       ├── renamed
│       │       │   └── acme-logging-engine.jar
│       │       └── student-app-9.8.7.jar
│       └── logs
│           ├── q3_dpkg_truth.txt
│           ├── q4_server_truth.txt
│           └── q4_unreachable_output.txt
└── README.md

21 directories, 42 files
```