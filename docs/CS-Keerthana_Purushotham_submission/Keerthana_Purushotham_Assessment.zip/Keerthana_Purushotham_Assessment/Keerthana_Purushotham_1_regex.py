  '''
  Question A.1. Common Detection Issues [Regex Validation]

  - Execute the following command in the terminal:
    > 
    >    `python3 Keerthana_Purushotham_1.py > Keerthana_Purushotham_1.txt` 
    >
  - This will run the script and save the output to a text file named "Keerthana_Purushotham_1.txt" in the same directory.
  - Open the "Keerthana_Purushotham_1.txt" file to review the results of the regex validation for each question. 
'''


import re


def question_1_1(text_1, pat_1_question, expected): # ideally, expected="Chrome/74.0.3729.157"
    print(f"Question 1.1:\nGiven the text: \"{text_1}\"\nAnd the pattern: r\'{str(pat_1_question)}\'\nThe expected output is: \"{expected}\".\n")  
''
    # PROOF:
    match_1_question = re.search(pat_1_question, text_1)
    try:
      assert match_1_question is not None, f"No match found for r\'{str(pat_1_question)}\' in the given text. Question 1.1 lists an incorrect pattern."
      assert match_1_question.group(0) == "Chrome/74.0.3729.157 ", f"Unexpected match: {match_1_question.group(0)}"
    except AssertionError as e:
      print(f"'AIL: {str(e)}") # GIVEN RE-pattern is WRONG

    print("\nHence, we correct the pattern as follows to get the expected output.\n")

    # SOLUTION 1.1.A:
    pat_1_sol_A1 = r'(?i)chrome/(\d+(?:\.\d+){1,3})' # This pattern matches "chrome/" followed by a version number with 1 to 4 components, separated by dots. Each component is a sequence of digits. The version number is captured in a group for later extraction.
    pat_1_sol_A2 = r'\d+(?:\.\d+){1,3}' # This pattern matches a version number with 1 to 4 components, separated by dots. Each component is a sequence of digits.
    # Reference Syntax: https://docs.python.org/3/library/re.html#:~:text=example%2C%20the%20expression-,(%3F%3Aa%7B6%7D)*,-matches%20any%20multiple
    
    # ALTERNATE SOLUTION 1.1.B: 
    pat_1_sol_B1 = r'(?i)chrome/(\d+\.\d+\.\d+\.\d+)' 

    match_1_sol_A1 = re.search(pat_1_sol_A1, text_1)
    if (match_1_sol_A1):
      assert match_1_sol_A1.group(0) == expected, f"Unexpected match: {match_1_sol_A1.group(0)}"
      match_1_A = re.search(pat_1_sol_A2, match_1_sol_A1.group(0))  

    match_1_sol_B1 = re.search(pat_1_sol_B1, text_1)
    if (match_1_sol_B1):
      assert match_1_sol_B1.group(0) == expected, f"Unexpected match: {match_1_sol_B1.group(0)}"
      match_1_B = re.search(pat_1_sol_A2, match_1_sol_B1.group(0))
                                    
    assert match_1_A is not None, "No version found"
    assert match_1_A.group(0) == "74.0.3729.157", f"Unexpected match: {match_1_A.group(0)}"

    assert match_1_B is not None, "No version found"
    assert match_1_B.group(0) == "74.0.3729.157", f"Unexpected match: {match_1_B.group(0)}"

    print(f"PASS: The correct pattern giving the expected output, \"{expected}\", is either:\n 1. \"{str(pat_1_sol_A1)}\", OR\n 2. \"{str(pat_1_sol_B1)}\"")
    print("------------------------------\n\n")


def question_1_2(text_2, pat_2_question, expected): # expected : Product Name and Version Number (e.g., "Adobe Photoshop", "1.2.3.patch")
    print(f"Question 1.2:\nGiven the text: \"{text_2}\"\nAnd the pattern: r\'{str(pat_2_question)}\'\nThe expected output is: {expected}.\n")
    # PROOF:
    try:
      match_2_question = re.search(pat_2_question, text_2)
      try:
        assert match_2_question is not None, f"No match found for r\'{str(pat_2_question)}\' in the given text. Question 1.2 lists an incorrect pattern."
        assert match_2_question.group(0) == "C:\\Program Files\\Adobe Photoshop\\1.2.3.patch", f"Unexpected match: {match_2_question.group(0)}"
      except AssertionError as e:
        print(f"FAIL: {str(e)}") # GIVEN RE-pattern fails to match the expected output, hence is WRONG.
    except re.error as e:
      print(f"FAIL: {str(e)}") # GIVEN RE-pattern is invalid, hence is WRONG.

    print("\nHence, we correct the pattern as follows to get the expected output.\n")

    # SOLUTION 1.2.A:
    pat_2_sol_A1 = r'[A-Z]:\\Program Files\\(Adobe Photoshop)\\(\d+\.\d+\.\d+\.patch)' # This pattern matches a Windows file path that starts with a drive letter, followed by "Program Files", then captures "Adobe Photoshop" and a version number with the format "1.2.3.patch". The version number is captured in a group for later extraction.
    # Reference Syntax: https://docs.python.org/3/library/re.html#re-syntax

    match_2_sol_A1 = re.search(pat_2_sol_A1, text_2)
    assert match_2_sol_A1 is not None, "No match found"
    assert match_2_sol_A1.group(0) == "C:\\Program Files\\Adobe Photoshop\\1.2.3.patch", f"Unexpected match: {match_2_sol_A1.group(0)}"

    match_2_A = match_2_sol_A1.group(1) # Extracting the product name "Adobe Photoshop"
    match_2_B = match_2_sol_A1.group(2) # Extracting the version number "1.2.3.patch"
    assert match_2_A == "Adobe Photoshop", f"Unexpected product name: {match_2_A}"
    assert match_2_B == "1.2.3.patch", f"Unexpected version number: {match_2_B}"

    print(f"PASS: The correct pattern giving the expected output, {expected}, is:\n \"{str(pat_2_sol_A1)}\"")
    print("------------------------------\n\n")


def question_1_3(text_3, pat_3_question, expected): # expected : Version (e.g., "45.1.13")
    print(f"Question 1.3:\nGiven the text: \"{text_3}\"\nAnd the pattern: r\'{str(pat_3_question)}\'\nThe expected output is: \"{expected}\".\n")

    # PROOF:
    match_3_question = re.search(pat_3_question, text_3)
    try:
      assert match_3_question is not None, f"No match found for r\'{str(pat_3_question)}\' in the given text. Question 1.3 lists an incorrect pattern."
      assert match_3_question.group(0) == "45.1.13", f"Unexpected match: {match_3_question.group(0)}"
    except AssertionError as e:
      print(f"FAIL: {str(e)}") # GIVEN RE-pattern is WRONG  
    
    print("\nHence, we correct the pattern as follows to get the expected output.\n")

    # SOLUTION 1.3.A:
    pat_3_sol_A1 = r'(\d+\.\d+\.\d+)' # This pattern matches a version number with the format "45.1.13". 
    # Reference Syntax: https://docs.python.org/3/library/re.html#re-syntax

    match_3_sol_A1 = re.search(pat_3_sol_A1, text_3)
    assert match_3_sol_A1 is not None, "No match found"
    assert match_3_sol_A1.group(0) == expected, f"Unexpected match: {match_3_sol_A1.group(0)}"

    print(f"PASS: The correct pattern giving the expected output, \"{expected}\", is:\n \"{str(pat_3_sol_A1)}\"")
    print("------------------------------\n\n")


def question_1_4(text_4, pat_4_question, expected): # expected : Path of the file (e.g., "C:\\Users\\Administrator\\Documents\\")
    print(f"Question 1.4:\nGiven the text: \"{text_4}\"\nAnd the pattern: r'{str(pat_4_question)}'\nThe expected output is: \"{expected}\".\n")

    # PROOF:
    match_4_question = re.search(pat_4_question, text_4)
    try:
      # group(0) returns the entire text matched by the whole regex.
      # group(1) returns the text matched by the first capture group, meaning the first pair of parentheses.
      assert match_4_question is not None, f"No match found for r'{str(pat_4_question)}' in the given text. Question 1.4 lists an incorrect pattern."
      assert match_4_question.group(1) == expected, f"Unexpected capture: {match_4_question.group(1)}" 
    except AssertionError as e:
      print(f"FAIL: {str(e)}") # GIVEN RE-pattern is WRONG  
    else:
      print(f"PASS: The given pattern r'{str(pat_4_question)}' gives the expected output, \"{expected}\".")
    
    print("\nHence, we correct the pattern as follows to get the expected output.\n")

    # SOLUTION 1.4.A:
    pat_4_sol_A1 = r'(^[A-Z]:\\.*\\)'

    match_4_sol_A1 = re.search(pat_4_sol_A1, text_4)
      # group(0) returns the entire text matched by the whole regex.
      # group(1) returns the text matched by the first capture group, meaning the first pair of parentheses.
    assert match_4_sol_A1 is not None, "No match found"
    assert match_4_sol_A1.group(1) == expected, f"Unexpected capture: {match_4_sol_A1.group(1)}"

    print(f"PASS: The correct pattern giving the expected output, \"{expected}\", is:\n \"{str(pat_4_sol_A1)}\"")
    print("------------------------------\n\n")


def question_1_5(text_5, pat_5_question, expected): # expected : Version (e.g., "50.5.4")
    print(f"Question 1.5:\nGiven the text: \"{text_5}\"\nAnd the pattern: r\'{str(pat_5_question)}\'\nThe expected output is: \"{expected}\".\n")

    # PROOF:
    match_5_question = re.search(pat_5_question, text_5)
    try:
      # group(0) returns the entire text matched by the whole regex.
      # group(1) returns the text matched by the first capture group, meaning the first pair of parentheses.
      assert match_5_question is not None, f"No match found for r\'{str(pat_5_question)}\' in the given text. Question 1.5 lists an incorrect pattern."
      assert match_5_question.group(0) == "50.5.4", f"Unexpected match: {match_5_question.group(0)}"
    except AssertionError as e:
      print(f"FAIL: {str(e)}") # GIVEN RE-pattern is WRONG

    print("\nHence, we correct the pattern as follows to get the expected output.\n")

    # SOLUTION 1.5.A:
    pat_5_sol_A1 = r'(\d+\.\d+\.\d+)' # This pattern matches a version number with the format "50.5.4".
    # Reference Syntax: https://docs.python.org/3/library/re.html#re-syntax

    match_5_sol_A1 = re.search(pat_5_sol_A1, text_5)
    assert match_5_sol_A1 is not None, "No match found"
    assert match_5_sol_A1.group(0) == expected, f"Unexpected match: {match_5_sol_A1.group(0)}"

    print(f"PASS: The correct pattern giving the expected output, \"{expected}\", is:\n \"{str(pat_5_sol_A1)}\"")
    print("------------------------------\n\n")



if __name__ == "__main__":
    text_1 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36"
    pat_1_question = r'(?i)chrome/(\D+.\d+\.\d+\.\d+)' # wrong
    question_1_1(text_1, pat_1_question, expected="Chrome/74.0.3729.157")

    text_2 = str("C:\\Program Files\\Adobe Photoshop\\1.2.3.patch") 
    pat_2_question = r'[A-z]:\Program Files\\(Adobe Photoshop)\\(\d.\d.\d.patch)' #invalid 
    question_1_2(text_2, pat_2_question, expected=["Adobe Photoshop","1.2.3.patch"])

    text_3 = "Amazon-product-45.1.13"
    pat_3_question = r'^.*(\d+\.\d+.\d+)'
    question_1_3(text_3, pat_3_question, expected="45.1.13")

    text_4 = "C:\\Users\\Administrator\\Documents\\patch.xml"
    pat_4_question = r'(^C:\\.*$)'
    question_1_4(text_4, pat_4_question, expected="C:\\Users\\Administrator\\Documents\\")

    text_5 = "Autodesk_Fusion360\\Fusion_50.5.4.exe"
    pat_5_question = r'^(\d+\.\d+\.\d+)'
    question_1_5(text_5, pat_5_question, expected="50.5.4")
