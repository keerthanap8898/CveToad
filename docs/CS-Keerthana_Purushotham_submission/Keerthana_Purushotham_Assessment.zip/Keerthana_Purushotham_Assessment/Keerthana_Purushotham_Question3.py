#!/usr/bin/env python3
"""
Keerthana_Purushotham_Question3.py

Purpose:
  On a Debian-based machine, report the full installed package version / EVR-like
  string for each exact package name requested by the assessment:
    apache2, libssh, python3, grep, mount, sed, procsp, php
  If the exact package is not installed, report it as missing.

Assumptions:
  - Intended target is Debian 12/13, Ubuntu 24.04, or another Debian-family OS.
  - dpkg-query is the authoritative source for Debian packages installed via apt,
    apt-get, aptitude, or dpkg -i.
  - Debian's version field already preserves the EVR semantics available to dpkg:
    [epoch:]upstream-version[-debian-revision]. Architecture is reported beside
    the version, but is not inserted into the EVR string.
  - The package names are preserved exactly as supplied. For example, procsp is
    reported missing if no exact package named procsp exists; related package
    hints such as procps are displayed separately.

Uncovered edge cases:
  - Snap, Flatpak, pip, and manually installed software do not necessarily use
    Debian EVR syntax. Those sources are reported as alternate-method evidence,
    not as Debian package EVR replacements.
  - A binary on PATH may be supplied by a different Debian package than its command
    name suggests. The script reports command presence separately from exact dpkg
    package state.
  - Source-built software can be present without package metadata.

Safety and load-control behavior:
  - Local package database and local command metadata only. No network calls.
  - Each subprocess has a timeout. Version probes are limited and non-interactive.
  - The script does not install, update, or remove packages.

Graceful error handling:
  - Missing tools, missing packages, and non-zero package-manager exits are treated
    as expected conditions and recorded in the output file.

Output:
  Writes Keerthana_Purushotham_Question3.txt by default, including the operating
  system where the script ran.
"""

from __future__ import annotations

import argparse
import datetime as dt
import platform
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

OUTPUT_DEFAULT = "Keerthana_Purushotham_Question3.txt"
REQUESTED_PACKAGES = ["apache2", "libssh", "python3", "grep", "mount", "sed", "procsp", "php"]
RELATED_PACKAGE_HINTS = {
    "libssh": ["libssh-4", "libssh-dev", "libssh-gcrypt-4"],
    "procsp": ["procps"],
    "mount": ["mount", "util-linux"],
}


@dataclass
class SourceEvidence:
    source: str
    name: str
    version: str = ""
    status: str = ""
    notes: str = ""


@dataclass
class PackageResult:
    requested_name: str
    exact_status: str
    exact_debian_evr: str = ""
    architecture: str = ""
    evidence: list[SourceEvidence] = field(default_factory=list)
    related: list[SourceEvidence] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def now_utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def run(command: list[str], timeout: int = 10) -> tuple[int, str, str]:
    try:
        completed = subprocess.run(
            command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=timeout, check=False,
        )
        return completed.returncode, completed.stdout, completed.stderr
    except FileNotFoundError:
        return 127, "", f"command not found: {command[0]}"
    except subprocess.TimeoutExpired as error:
        return 124, error.stdout or "", f"command timed out after {timeout}s"
    except Exception as error:
        return 1, "", f"command failed: {error}"


def os_summary() -> str:
    os_release = Path("/etc/os-release")
    if os_release.exists():
        values: dict[str, str] = {}
        try:
            for line in os_release.read_text(encoding="utf-8", errors="replace").splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    values[key] = value.strip().strip('"')
            if values.get("PRETTY_NAME"):
                return f"{values['PRETTY_NAME']} ({platform.platform()})"
        except OSError:
            pass
    return platform.platform()


def dpkg_query(package_name: str) -> SourceEvidence | None:
    if shutil.which("dpkg-query") is None:
        return SourceEvidence("dpkg-query", package_name, status="tool-missing", notes="dpkg-query not found")
    fmt = "${binary:Package}\t${Version}\t${Architecture}\t${db:Status-Status}\n"
    code, stdout, stderr = run(["dpkg-query", "-W", f"-f={fmt}", package_name], 10)
    if code != 0 or not stdout.strip():
        return None
    first = stdout.splitlines()[0].split("\t")
    while len(first) < 4:
        first.append("")
    name, version, architecture, status = first[:4]
    return SourceEvidence("dpkg-query", name, version, status, notes=f"architecture={architecture}")


def snap_query(package_name: str) -> SourceEvidence | None:
    if shutil.which("snap") is None:
        return None
    code, stdout, stderr = run(["snap", "list", package_name], 8)
    if code != 0:
        return None
    lines = [line for line in stdout.splitlines() if line.strip()]
    if len(lines) < 2:
        return None
    fields = re.split(r"\s+", lines[1].strip())
    if len(fields) >= 2:
        return SourceEvidence("snap", fields[0], fields[1], "installed", "non-Debian version semantics")
    return None


def flatpak_query(package_name: str) -> SourceEvidence | None:
    if shutil.which("flatpak") is None:
        return None
    code, stdout, stderr = run(["flatpak", "list", "--columns=application,version"], 10)
    if code != 0:
        return None
    for line in stdout.splitlines():
        fields = line.split("\t")
        app_id = fields[0] if fields else ""
        version = fields[1] if len(fields) > 1 else ""
        if package_name.lower() in app_id.lower():
            return SourceEvidence("flatpak", app_id, version, "installed", "non-Debian version semantics")
    return None


def command_query(package_name: str) -> SourceEvidence | None:
    command_name = "python3" if package_name == "python3" else package_name
    path = shutil.which(command_name)
    if not path:
        return None
    code, stdout, stderr = run([path, "--version"], 5)
    text = (stdout or stderr).strip().splitlines()[0] if (stdout or stderr).strip() else "version probe produced no output"
    return SourceEvidence("PATH command", command_name, text, "present", f"path={path}; command presence is not exact package proof")


def pip_query(package_name: str) -> SourceEvidence | None:
    if shutil.which("python3") is None:
        return None
    code, stdout, stderr = run(["python3", "-m", "pip", "show", package_name], 8)
    if code != 0 or not stdout.strip():
        return None
    name = package_name
    version = ""
    for line in stdout.splitlines():
        if line.lower().startswith("name:"):
            name = line.split(":", 1)[1].strip()
        elif line.lower().startswith("version:"):
            version = line.split(":", 1)[1].strip()
    return SourceEvidence("pip", name, version, "installed", "Python package metadata, not Debian EVR")


def evaluate_package(package_name: str) -> PackageResult:
    result = PackageResult(package_name, "missing")
    exact = dpkg_query(package_name)
    if exact and exact.status != "tool-missing":
        result.evidence.append(exact)
        if exact.status == "installed":
            result.exact_status = "installed"
            result.exact_debian_evr = exact.version
            arch_match = re.search(r"architecture=([^;]+)", exact.notes)
            result.architecture = arch_match.group(1) if arch_match else ""
        else:
            result.exact_status = exact.status or "not-installed"
    elif exact and exact.status == "tool-missing":
        result.warnings.append(exact.notes)

    for query in (snap_query, flatpak_query, pip_query, command_query):
        evidence = query(package_name)
        if evidence:
            result.evidence.append(evidence)

    for related_name in RELATED_PACKAGE_HINTS.get(package_name, []):
        related_exact = dpkg_query(related_name)
        if related_exact and related_exact.status == "installed":
            result.related.append(related_exact)
    return result


def write_report(output: Path, results: list[PackageResult]) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="\n") as report:
        report.write("Keerthana_Purushotham_Question3 - Debian Package EVR Report\n")
        report.write("=" * 78 + "\n\n")
        report.write(f"Generated UTC: {now_utc()}\n")
        report.write(f"Operating system the script was run on: {os_summary()}\n")
        report.write(f"Python runtime: {sys.version.replace(chr(10), ' ')}\n")
        report.write("Requested package names are preserved exactly as provided.\n")
        report.write("Debian EVR source: dpkg-query Version field.\n\n")

        report.write("Exact requested package results\n")
        report.write("-" * 78 + "\n")
        for result in results:
            evr = result.exact_debian_evr if result.exact_debian_evr else "MISSING"
            report.write(f"Package: {result.requested_name}\n")
            report.write(f"  Exact status: {result.exact_status}\n")
            report.write(f"  Full Debian EVR/version string: {evr}\n")
            report.write(f"  Architecture: {result.architecture or 'n/a'}\n")
            if result.evidence:
                report.write("  Evidence:\n")
                for evidence in result.evidence:
                    report.write(f"    - {evidence.source}: name={evidence.name}; version={evidence.version or 'unknown'}; status={evidence.status or 'unknown'}; notes={evidence.notes or 'n/a'}\n")
            if result.related:
                report.write("  Related installed package hints, not exact-name substitutes:\n")
                for evidence in result.related:
                    report.write(f"    - {evidence.name}: {evidence.version}; {evidence.notes}\n")
            for warning in result.warnings:
                report.write(f"  Warning: {warning}\n")
            report.write("\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Report exact Debian package EVR/version strings for requested packages.")
    parser.add_argument("--output", default=OUTPUT_DEFAULT)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    results = [evaluate_package(name) for name in REQUESTED_PACKAGES]
    write_report(Path(args.output), results)
    print(f"Wrote report: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
