#!/usr/bin/env python3
"""
Keerthana_Purushotham_Question1.py

Purpose:
  Inventory programs on a Windows Workstation/client OS and verify whether an
  executable exists on disk for each program. For each program, report the common
  display name, display version, and executable path/version matches when found.

Assumptions:
  - Intended target is Windows 10/11 Workstation/client, not Windows Server.
    Win32_OperatingSystem.ProductType is checked and reported; ProductType=1 is
    the expected workstation/client value.
  - Standard-library Python only. No non-standard Python packages are required.
  - Coverage is best when the script runs elevated, but it still writes partial
    results without administrator privileges.
  - Per-user applications are collected from HKCU and from already-loaded user
    hives under HKEY_USERS. The script does not load offline NTUSER.DAT hives.

Uncovered edge cases:
  - Some applications do not write uninstall registry metadata or version fields.
  - Store/AppX/MSIX packages and DISM/Windows packages do not always map to a
    conventional .exe file or a single user-facing application name.
  - Some products expose launcher executables whose PE file version differs from
    the product display version even though the launcher belongs to the product.
  - Some software uses scripts, protocol handlers, services, or shell aliases
    instead of discoverable .exe launchers.

Safety and load-control behavior:
  - Local read-only registry, local read-only file metadata, and bounded
    PowerShell/DISM queries only. The script does not modify the system.
  - Executable discovery starts from registry-provided paths. It does not walk the
    whole disk unless explicit registry paths point there.
  - Directory traversal is bounded by --max-depth and --max-files-per-program.
  - External commands have timeouts. Applications are never launched.

Graceful error handling:
  - Registry access errors, missing install paths, unreadable directories,
    malformed version resources, missing PowerShell, AppX failures, and DISM
    failures are recorded as notes/warnings rather than unhandled exceptions.

Output:
  Writes Keerthana_Purushotham_Question1.txt by default, including the operating
  system where the script ran.
"""

from __future__ import annotations

import argparse
import ctypes
import datetime as dt
import json
import os
import platform
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

try:
    import winreg  # Windows-only standard library module
except ImportError:  # pragma: no cover
    winreg = None  # type: ignore

OUTPUT_DEFAULT = "Keerthana_Purushotham_Question1.txt"
UNINSTALL_KEY = r"Software\Microsoft\Windows\CurrentVersion\Uninstall"


@dataclass
class ExecutableFinding:
    path: str
    file_version: str = ""
    product_version: str = ""
    same_version: bool = False
    reason: str = ""


@dataclass
class ProgramRecord:
    source: str
    key_path: str
    name: str
    version: str = ""
    publisher: str = ""
    install_location: str = ""
    display_icon: str = ""
    uninstall_string: str = ""
    modify_path: str = ""
    architecture: str = ""
    executables: list[ExecutableFinding] = field(default_factory=list)
    checked_executables: int = 0
    notes: list[str] = field(default_factory=list)


@dataclass
class AuxiliaryRecord:
    source: str
    name: str
    version: str = ""
    state: str = ""
    install_location: str = ""
    notes: str = ""


def now_utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def run(command: list[str], timeout: int = 30) -> tuple[int, str, str]:
    try:
        completed = subprocess.run(
            command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=timeout, check=False,
        )
        return completed.returncode, completed.stdout, completed.stderr
    except FileNotFoundError:
        return 127, "", f"command not found: {command[0]}"
    except subprocess.TimeoutExpired as error:
        return 124, error.stdout or "", f"command timed out after {timeout}s"
    except Exception as error:  # defensive guard for assessment readability
        return 1, "", f"command failed: {error}"


def expand_windows_path(value: str) -> str:
    if not value:
        return ""
    value = os.path.expandvars(str(value).strip().strip('"'))
    value = value.replace("/", "\\") if ":/" in value else value
    return value


def registry_value(key, name: str) -> str:
    try:
        value, _ = winreg.QueryValueEx(key, name)
        if isinstance(value, (list, tuple)):
            return "; ".join(str(item) for item in value)
        return "" if value is None else str(value).strip()
    except OSError:
        return ""


def os_report() -> dict[str, str]:
    result = {
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "python": sys.version.replace("\n", " "),
        "caption": "unknown",
        "product_type": "unknown",
        "is_workstation": "unknown",
    }
    if platform.system().lower() != "windows":
        result["is_workstation"] = "not-windows"
        return result

    command = (
        "Get-CimInstance Win32_OperatingSystem | "
        "Select-Object Caption,Version,ProductType,OSArchitecture | "
        "ConvertTo-Json -Compress"
    )
    code, stdout, stderr = run(["powershell", "-NoProfile", "-Command", command], 20)
    if code == 0 and stdout.strip():
        try:
            data = json.loads(stdout)
            result["caption"] = str(data.get("Caption", "unknown"))
            result["version"] = str(data.get("Version", result["version"]))
            result["product_type"] = str(data.get("ProductType", "unknown"))
            result["os_architecture"] = str(data.get("OSArchitecture", "unknown"))
            result["is_workstation"] = "yes" if str(data.get("ProductType")) == "1" else "no"
        except json.JSONDecodeError:
            result["cim_warning"] = "PowerShell CIM returned non-JSON output"
    else:
        result["cim_warning"] = stderr.strip() or "CIM query failed"
    return result


def enum_uninstall(root, root_name: str, subkey: str, access_flag: int, source: str) -> list[ProgramRecord]:
    records: list[ProgramRecord] = []
    if winreg is None:
        return records
    try:
        with winreg.OpenKey(root, subkey, 0, winreg.KEY_READ | access_flag) as parent:
            count = winreg.QueryInfoKey(parent)[0]
            for index in range(count):
                try:
                    child = winreg.EnumKey(parent, index)
                    child_path = f"{subkey}\\{child}"
                    with winreg.OpenKey(root, child_path, 0, winreg.KEY_READ | access_flag) as key:
                        name = registry_value(key, "DisplayName")
                        if not name:
                            continue
                        notes = []
                        if registry_value(key, "SystemComponent") == "1":
                            notes.append("SystemComponent=1; retained because the task asks for all programs")
                        for label in ("ReleaseType", "ParentKeyName"):
                            value = registry_value(key, label)
                            if value:
                                notes.append(f"{label}={value}")
                        records.append(ProgramRecord(
                            source=source,
                            key_path=f"{root_name}\\{child_path}",
                            name=name,
                            version=registry_value(key, "DisplayVersion"),
                            publisher=registry_value(key, "Publisher"),
                            install_location=expand_windows_path(registry_value(key, "InstallLocation")),
                            display_icon=registry_value(key, "DisplayIcon"),
                            uninstall_string=registry_value(key, "UninstallString"),
                            modify_path=registry_value(key, "ModifyPath"),
                            architecture="32-bit view" if access_flag == getattr(winreg, "KEY_WOW64_32KEY", 0) else "64-bit/default view",
                            notes=notes,
                        ))
                except OSError:
                    continue
    except OSError:
        pass
    return records


def collect_registry_programs() -> list[ProgramRecord]:
    if winreg is None:
        return []
    records: list[ProgramRecord] = []
    key64 = getattr(winreg, "KEY_WOW64_64KEY", 0)
    key32 = getattr(winreg, "KEY_WOW64_32KEY", 0)
    records.extend(enum_uninstall(winreg.HKEY_LOCAL_MACHINE, "HKLM", UNINSTALL_KEY, key64, "HKLM uninstall 64-bit view"))
    if platform.machine().endswith("64") or "64" in platform.architecture()[0]:
        records.extend(enum_uninstall(winreg.HKEY_LOCAL_MACHINE, "HKLM", UNINSTALL_KEY, key32, "HKLM uninstall 32-bit WOW6432 view"))
    records.extend(enum_uninstall(winreg.HKEY_CURRENT_USER, "HKCU", UNINSTALL_KEY, 0, "HKCU current-user uninstall"))

    try:
        with winreg.OpenKey(winreg.HKEY_USERS, "") as users:
            for index in range(winreg.QueryInfoKey(users)[0]):
                sid = winreg.EnumKey(users, index)
                if sid.endswith("_Classes"):
                    continue
                records.extend(enum_uninstall(winreg.HKEY_USERS, "HKU", f"{sid}\\{UNINSTALL_KEY}", 0, f"HKU loaded-user uninstall {sid}"))
    except OSError:
        pass
    return records


def dedupe_programs(records: list[ProgramRecord]) -> list[ProgramRecord]:
    seen: dict[tuple[str, str, str], ProgramRecord] = {}
    for record in records:
        key = (record.name.casefold(), record.version.casefold(), record.publisher.casefold())
        if key not in seen:
            seen[key] = record
        else:
            seen[key].notes.append(f"Duplicate source also seen at {record.key_path}")
    return sorted(seen.values(), key=lambda item: (item.name.casefold(), item.version.casefold()))


def first_exe_from_text(text: str) -> str:
    if not text:
        return ""
    expanded = expand_windows_path(text)
    quoted = re.search(r'"([^\"]+\.exe)"', expanded, flags=re.IGNORECASE)
    if quoted:
        return quoted.group(1)
    unquoted = re.search(r'([A-Za-z]:\\[^\n\r\t]*?\.exe)', expanded, flags=re.IGNORECASE)
    if unquoted:
        return unquoted.group(1).strip()
    return ""


def candidate_directories(record: ProgramRecord) -> list[Path]:
    directories: list[Path] = []
    for value in (record.install_location, first_exe_from_text(record.display_icon), first_exe_from_text(record.uninstall_string), first_exe_from_text(record.modify_path)):
        if not value:
            continue
        path = Path(value)
        if path.suffix.lower() == ".exe":
            path = path.parent
        if path.exists() and path.is_dir() and path not in directories:
            directories.append(path)
    return directories


def candidate_executables(record: ProgramRecord, max_depth: int, max_files: int) -> list[Path]:
    ordered: list[Path] = []
    for text in (record.display_icon, record.uninstall_string, record.modify_path):
        path_text = first_exe_from_text(text)
        if path_text:
            path = Path(path_text)
            if path.exists() and path.is_file() and path.suffix.lower() == ".exe" and path not in ordered:
                ordered.append(path)
    for directory in candidate_directories(record):
        root_depth = len(directory.parts)
        try:
            for current_root, subdirs, filenames in os.walk(directory):
                current = Path(current_root)
                if len(current.parts) - root_depth >= max_depth:
                    subdirs[:] = []
                for filename in filenames:
                    if filename.lower().endswith(".exe"):
                        path = current / filename
                        if path not in ordered:
                            ordered.append(path)
                        if len(ordered) >= max_files:
                            return ordered
        except OSError as error:
            record.notes.append(f"Could not walk {directory}: {error}")
    return ordered[:max_files]


def executable_version(path: Path) -> tuple[str, str, str]:
    escaped = str(path).replace("'", "''")
    command = (
        "$i=Get-Item -LiteralPath '" + escaped + "' -ErrorAction Stop; "
        "$i.VersionInfo | Select-Object FileVersion,ProductVersion,ProductName | ConvertTo-Json -Compress"
    )
    code, stdout, stderr = run(["powershell", "-NoProfile", "-Command", command], 8)
    if code != 0 or not stdout.strip():
        return "", "", stderr.strip()
    try:
        data = json.loads(stdout)
        return str(data.get("FileVersion") or ""), str(data.get("ProductVersion") or ""), str(data.get("ProductName") or "")
    except json.JSONDecodeError:
        return "", "", "could not parse executable version JSON"


def version_tokens(value: str) -> tuple[int, ...]:
    numbers = re.findall(r"\d+", value or "")
    return tuple(int(item) for item in numbers[:6])


def versions_compatible(display_version: str, exe_file_version: str, exe_product_version: str) -> tuple[bool, str]:
    wanted = version_tokens(display_version)
    if not wanted:
        return False, "program has no comparable DisplayVersion"
    for label, candidate in (("FileVersion", exe_file_version), ("ProductVersion", exe_product_version)):
        got = version_tokens(candidate)
        if got:
            width = max(len(wanted), len(got))
            if wanted + (0,) * (width - len(wanted)) == got + (0,) * (width - len(got)):
                return True, f"{label} matches DisplayVersion after numeric normalization"
            if got[: len(wanted)] == wanted:
                return True, f"{label} starts with DisplayVersion numeric tokens"
    return False, "version did not match"


def enrich_with_executables(records: list[ProgramRecord], max_depth: int, max_files: int) -> None:
    for record in records:
        for executable in candidate_executables(record, max_depth, max_files):
            file_version, product_version, version_note = executable_version(executable)
            same, reason = versions_compatible(record.version, file_version, product_version)
            record.executables.append(ExecutableFinding(str(executable), file_version, product_version, same, reason))
            if version_note:
                record.notes.append(f"Version read note for {executable}: {version_note}")
        record.checked_executables = len(record.executables)
        if not record.executables:
            record.notes.append("No executable candidate found from registry-derived paths")


def collect_appx() -> list[AuxiliaryRecord]:
    command = (
        "Get-AppxPackage -AllUsers | Select-Object Name,PackageFullName,Version,InstallLocation | ConvertTo-Json -Compress"
    )
    code, stdout, stderr = run(["powershell", "-NoProfile", "-Command", command], 60)
    if code != 0 or not stdout.strip():
        return [AuxiliaryRecord("AppX/MSIX", "collection warning", notes=stderr.strip() or "Get-AppxPackage returned no data")]
    try:
        data = json.loads(stdout)
        rows = data if isinstance(data, list) else [data]
        return [AuxiliaryRecord("AppX/MSIX", str(row.get("Name", "")), str(row.get("Version", "")), install_location=str(row.get("InstallLocation", ""))) for row in rows if row.get("Name")]
    except Exception as error:
        return [AuxiliaryRecord("AppX/MSIX", "parse warning", notes=str(error))]


def collect_dism() -> list[AuxiliaryRecord]:
    command = "Get-WindowsPackage -Online | Select-Object PackageName,PackageState,ReleaseType | ConvertTo-Json -Compress"
    code, stdout, stderr = run(["powershell", "-NoProfile", "-Command", command], 90)
    if code != 0 or not stdout.strip():
        return [AuxiliaryRecord("DISM/WindowsPackage", "collection warning", notes=stderr.strip() or "Get-WindowsPackage returned no data")]
    try:
        data = json.loads(stdout)
        rows = data if isinstance(data, list) else [data]
        output = []
        for row in rows:
            name = str(row.get("PackageName", ""))
            version = ""
            parts = name.split("~")
            if len(parts) >= 5:
                version = parts[-1]
            if name:
                output.append(AuxiliaryRecord("DISM/WindowsPackage", name, version, str(row.get("PackageState", "")), notes=str(row.get("ReleaseType", ""))))
        return output
    except Exception as error:
        return [AuxiliaryRecord("DISM/WindowsPackage", "parse warning", notes=str(error))]


def collect_dotnet() -> list[AuxiliaryRecord]:
    output: list[AuxiliaryRecord] = []
    if winreg is not None:
        base = r"SOFTWARE\Microsoft\NET Framework Setup\NDP"
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base) as root:
                for i in range(winreg.QueryInfoKey(root)[0]):
                    name = winreg.EnumKey(root, i)
                    try:
                        with winreg.OpenKey(root, name) as child:
                            version = registry_value(child, "Version")
                            release = registry_value(child, "Release")
                            if version or release:
                                output.append(AuxiliaryRecord(".NET Framework registry", name, version, notes=f"Release={release}" if release else ""))
                    except OSError:
                        continue
        except OSError:
            pass
    code, stdout, stderr = run(["dotnet", "--list-runtimes"], 20)
    if code == 0:
        for line in stdout.splitlines():
            match = re.match(r"^(.*?)\s+([0-9][^\s]*)\s+\[(.*)\]$", line.strip())
            if match:
                output.append(AuxiliaryRecord("dotnet --list-runtimes", match.group(1), match.group(2), install_location=match.group(3)))
    elif stderr.strip():
        output.append(AuxiliaryRecord("dotnet --list-runtimes", "collection warning", notes=stderr.strip()))
    return output


def write_report(path: Path, os_info: dict[str, str], records: list[ProgramRecord], aux: list[AuxiliaryRecord], warnings: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as report:
        report.write("Keerthana_Purushotham_Question1 - Windows Workstation Program Inventory\n")
        report.write("=" * 78 + "\n\n")
        report.write(f"Generated UTC: {now_utc()}\n")
        report.write(f"Operating system the script was run on: {os_info}\n")
        report.write(f"Windows Workstation/client expected: yes, observed: {os_info.get('is_workstation')}\n")
        report.write(f"Program records from registry: {len(records)}\n")
        report.write(f"Auxiliary AppX/DISM/.NET records: {len(aux)}\n\n")

        report.write("Registry software records and executable verification\n")
        report.write("-" * 78 + "\n")
        for number, record in enumerate(records, 1):
            report.write(f"[{number}] Name: {record.name}\n")
            report.write(f"    Version: {record.version or 'unknown'}\n")
            report.write(f"    Publisher: {record.publisher or 'unknown'}\n")
            report.write(f"    Source: {record.source}\n")
            report.write(f"    Registry path: {record.key_path}\n")
            report.write(f"    InstallLocation: {record.install_location or 'not provided'}\n")
            report.write(f"    Executables checked: {record.checked_executables}\n")
            if record.executables:
                for exe in record.executables:
                    flag = "MATCH" if exe.same_version else "NO_MATCH"
                    report.write(f"      - {flag}: {exe.path}\n")
                    report.write(f"        FileVersion={exe.file_version or 'unknown'}\n")
                    report.write(f"        ProductVersion={exe.product_version or 'unknown'}\n")
                    report.write(f"        Reason={exe.reason}\n")
            else:
                report.write("      - No executable found from bounded registry-derived paths\n")
            for note in record.notes:
                report.write(f"    Note: {note}\n")
            report.write("\n")

        report.write("Auxiliary AppX/MSIX, DISM/WindowsPackage, and .NET records\n")
        report.write("-" * 78 + "\n")
        for item in aux:
            report.write(f"- Source={item.source}; Name={item.name}; Version={item.version or 'unknown'}; State={item.state or 'n/a'}; Location={item.install_location or 'n/a'}; Notes={item.notes or 'n/a'}\n")

        report.write("\nWarnings\n")
        report.write("-" * 78 + "\n")
        if not warnings:
            report.write("No top-level warnings. Per-program notes may still exist.\n")
        for warning in warnings:
            report.write(f"- {warning}\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Inventory Windows Workstation software and bounded executable version matches.")
    parser.add_argument("--output", default=OUTPUT_DEFAULT)
    parser.add_argument("--max-depth", type=int, default=2)
    parser.add_argument("--max-files-per-program", type=int, default=25)
    parser.add_argument("--skip-appx", action="store_true")
    parser.add_argument("--skip-dism", action="store_true")
    parser.add_argument("--skip-dotnet", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    warnings: list[str] = []
    os_info = os_report()
    if platform.system().lower() != "windows":
        warnings.append("This script is intended for Windows Workstation; non-Windows runtime detected.")
    if os_info.get("is_workstation") == "no":
        warnings.append("Windows ProductType does not indicate Workstation/client.")
    if winreg is None:
        warnings.append("winreg unavailable; registry inventory cannot run on this OS.")

    records = dedupe_programs(collect_registry_programs())
    enrich_with_executables(records, max(0, args.max_depth), max(1, args.max_files_per_program))

    auxiliary: list[AuxiliaryRecord] = []
    if not args.skip_appx:
        auxiliary.extend(collect_appx())
    if not args.skip_dism:
        auxiliary.extend(collect_dism())
    if not args.skip_dotnet:
        auxiliary.extend(collect_dotnet())

    write_report(Path(args.output), os_info, records, auxiliary, warnings)
    print(f"Wrote report: {args.output}")
    return 0 if records or auxiliary else 1


if __name__ == "__main__":
    raise SystemExit(main())
